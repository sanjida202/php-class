<?php
// echo $text = 'this is php tutorial';
// echo "<br>";
// echo strlen($text);
// echo str_word_count($text);
// echo strpos($text,'php');
// echo str_replace('php', 'PHP', $text);
// $x=1;
// while($x<=5){
//     echo $x."Alga koro khopar badhon dil wohi mera bach geyi <br>";
//     $x++;
// }
// $x=1;
// do{
//     echo $x."Alga koro khopar badhon. <br>";
//     $x++;
// }
// while($x<=20);
$x=1;
for( $x; $x <20;$x++){
    echo 'Bangladesh is the most beautiful country in the world.<br>';
}
?>
